#!/bin/bash
# =========================
# git 同步脚本
#
# Author: 余小波
# Date: 2020-01-09
# =========================

# 设置变量
REMOTE_URL="https://github.com/wzsvip/git.git"
LOCAL_DIR="my_local_repo"
SOURCE_DIR="/storage/emulated/0/01111/crx" #本地目录路径
BRANCH="main"  # 或者你希望使用的分支名称

# 创建并进入本地目录
mkdir -p $LOCAL_DIR
cd $LOCAL_DIR

# 克隆远程仓库到本地目录
if [ ! -d "$LOCAL_DIR/.git" ]; then
    git clone $REMOTE_URL .
fi

# 进入克隆后的目录
cd git

# 复制源目录内容到当前目录
cp -r "../$SOURCE_DIR/." .

# 本地文件是否发生了改变
is_change=$(git status -s)

# remark
if [ -n "$1" ]; then 
    guser=$1
else
    # git.user.name
    guser="$(git config user.name) update"
fi

if [ 0 -lt ${#is_change} ]; then
    git add .
    git commit -m "$guser"
    # pull
    result=$(git pull origin $BRANCH)
    tmp=$(echo $result | grep "fix conflicts")
    if [ "$tmp" != "" ]
    then
        echo "(ノ=Д=)ノ┻━┻ 合并冲突, 请手动解决后提交"
    else
        # 推送
        git push origin $BRANCH
    fi
    
else
    echo "本地没有改变, 正在从远程仓库同步代码. 请耐心等待 ╭(●｀∀´●)╯╰(●’◡’●)╮";
    result=$(git pull origin $BRANCH)
    tmp=$(echo $result | grep "fix conflicts")
    if [[ "$tmp" != "" ]]
    then
      echo "(ノ=Д=)ノ┻━┻ 合并冲突, 请手动解决后提交"
    fi
fi